/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sptech.terceira.lista.nivelamento;

/**
 *
 * @author Nathan
 */
public class TesteClasseSocial {
     Double renda (Double numero01, Double numero02) {
        return numero01 / numero02;
    }
    
    String classe (Double salario){
        String classe;
        
        if (salario < 2){
            classe = "E";
        }else if (salario < 4){
            classe = "D";
        }else if (salario < 10){
            classe = "C"; 
        }else if (salario < 20){
            classe = "B"; 
        }else{
            classe = "A"; 
        }
        
        return classe;
        
        
    }
}
