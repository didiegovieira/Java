/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sptech.terceira.lista.nivelamento;

import java.util.Scanner;

/**
 *
 * @author Nathan
 */
public class ClasseSocial {
    public static void main(String[] args) {
        TesteClasseSocial teste = new TesteClasseSocial();
        Scanner read = new Scanner(System.in);
        
        System.out.println("Digite sua renda:");
        Double digitado = read.nextDouble();
        
        Double renda = teste.renda(digitado, 1045.0);
        
        System.out.println(String.format( "Você recebe aproximadamente %.2f salários-mínimos.", renda));
        
        String classe = teste.classe(renda);
        System.out.println(String.format("Você pertence a classe social: %s", classe));
    }
}
