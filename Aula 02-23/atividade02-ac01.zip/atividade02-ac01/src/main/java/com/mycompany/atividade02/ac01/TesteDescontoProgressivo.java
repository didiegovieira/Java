/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

import java.util.Scanner;

/**
 *
 * @author diego
 */
public class TesteDescontoProgressivo {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        DescontoProgressivo desconto = new DescontoProgressivo();
        
        System.out.println("Digite o valor unitario do produto:");
        Double valorUni = read.nextDouble();
        System.out.println("Digite a quantidade:");
        Integer quant = read.nextInt();
        
        System.out.println(desconto.exibirNotaFiscal(valorUni, quant));
        System.out.println(desconto.calcularDesconto(valorUni, quant));
    }
}
