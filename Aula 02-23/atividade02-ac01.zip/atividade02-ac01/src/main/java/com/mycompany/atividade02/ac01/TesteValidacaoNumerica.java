/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

import java.util.Scanner;

/**
 *
 * @author diego
 */
public class TesteValidacaoNumerica {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        ValidacaoNumerica numero = new ValidacaoNumerica();
        Integer num = 1;
        
        while (num > 0) {            
            System.out.println("Digite um numero positivo:");
            num = read.nextInt();
            
            if(num < 0){
                break;
            }
            
            System.out.println(numero.verificarPrimo(num));
        }
    }
}
