/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

/**
 *
 * @author diego
 */
public class ValidacaoNumerica {
    String verificarPrimo(Integer num) {
        String texto = "";
        Integer cont = 0;

        for (int i = 1; i <= num; i++) {
            
            if (num % i == 0) {
                cont++;
            }
        }
        
        if(cont == 2){
            texto = "É primo";
        }else {
            texto = "Não é primo";
        }
        
        return texto;
    }
    
}
