/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

import java.util.Scanner;

/**
 *
 * @author diego
 */
public class TesteCalculoNutricao {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        CalculoNutricao calculo = new CalculoNutricao();
        
        System.out.println("Qual seu peso:");
        Double peso = read.nextDouble();
        
        System.out.println("Qual sua altura:");
        Double altura = read.nextDouble();
        
        System.out.println(calculo.calculaIMC(peso, altura));
    }
}
