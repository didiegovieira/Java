/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

/**
 *
 * @author diego
 */
public class Idade {
    String classificaIdade(Integer idade) {
        String texto = "";
        
        if (idade >= 0 && idade <= 2) {
            texto = "0 a 2 anos - 'Bebê'";
        }else if (idade >= 3 && idade <= 11) {
            texto = "3 a 11 anos - 'Criança'";
        }else if (idade >= 12 && idade <= 19) {
            texto = "12 a 19 anos - 'Adolescente'";
        }else if (idade >= 20 && idade <= 30) {
            texto = "20 a 30 anos - 'Bebê'";
        }else if (idade >= 31 && idade <= 60) {
            texto = "31 a 60 anos - 'Bebê'";
        }else if (idade > 60) {
            texto = "acima de 60 anos - 'Bebê'";
        }
        
        return texto;
    }
}
