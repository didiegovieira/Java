/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

/**
 *
 * @author diego
 */
public class DescontoProgressivo {
    String calcularDesconto (Double valor, Integer quantidade) {
        Double desconto = 0.0;
        
        if(quantidade == 1 ) {
            desconto = 0.9;
        }else if(quantidade == 2 ) {
            desconto = 0.8;
        }else if(quantidade >= 3 ) {
            desconto = 0.7;
        }
        
        Double valorFinal = (valor * desconto) * quantidade;
        
        String texto = "Valor com desconto: " + valorFinal;
        
        return texto;
    }
    
    String exibirNotaFiscal (Double valor, Integer quantidade){
        String notaFiscal = "-------------------------------------------------\n"
                + "Valor do produto: " + valor + "\nQuantidade: " + quantidade + 
                "\n-------------------------------------------------";
        
        return notaFiscal;
    }
}
