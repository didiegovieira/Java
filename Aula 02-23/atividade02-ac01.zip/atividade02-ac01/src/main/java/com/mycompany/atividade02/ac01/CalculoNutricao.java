/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

/**
 *
 * @author diego
 */
public class CalculoNutricao {
    String calculaIMC(Double peso, Double altura) {
        Double imc = peso / (altura * altura);
        
        String texto = String.format("O seu imc é: %.2f", imc);
        
        return texto;
    }
}
