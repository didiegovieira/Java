/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

import java.util.Scanner;

/**
 *
 * @author diego
 */
public class TesteCalculoAluno {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        CalculoAluno calculo = new CalculoAluno();
        
        System.out.println("Olá Fulano!");
        System.out.println("Digite sua primeira nota: ");
        Double nota1 = read.nextDouble();
        
        System.out.println("Digite sua segunda nota: ");
        Double nota2 = read.nextDouble();
        
        Double result = calculo.calcularMedia(nota1, nota2);
        System.out.println(String.format("A sua nota média na SPTech foi: %.2f", result));
    }
}
