/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.atividade02.ac01;

import java.util.Scanner;

/**
 *
 * @author diego
 */
public class TesteIdade {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        Idade idade = new Idade();
        
        System.out.println("Diga sua idade: ");
        Integer digitado = read.nextInt();
        
        System.out.println(idade.classificaIdade(digitado));
    }
}
// segundo o enunciado abaixo eu preciso retornar a mensagem de uma faixa etaria
// especifica, mas como vou fazer isso com o metodo sendo void? nao entendi esta
// questao... por isso fiz com return la no metodo.

//Escreva o método classificaIdade (não retorna nada) que recebe uma idade e imprime uma 
//mensagem conforme a faixa etária à qual pertence a idade conforme regra abaixo:
//• 0 a 2 anos - “Bebê”
//• 3 a 11 anos -“Criança”
//• 12 a 19 anos -“Adolescente”
//• 20 a 30 anos - “Jovem”
//• 31 a 60 anos -“Adulto”
//• acima de 60 anos -“Idoso”.
//Crie uma classe TesteIdade, escreva o método main e solicite que o usuário digite a sua idade, 
//testes os métodos da classe Idade