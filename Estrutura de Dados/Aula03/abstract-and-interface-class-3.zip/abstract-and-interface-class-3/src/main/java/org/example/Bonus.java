package org.example;

public interface Bonus {
    public double getValorBonus();

}
