package ac1.RA01222015pratica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ra01222015PraticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
