package ac1.RA01222015pratica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ra01222015PraticaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ra01222015PraticaApplication.class, args);
	}

}
