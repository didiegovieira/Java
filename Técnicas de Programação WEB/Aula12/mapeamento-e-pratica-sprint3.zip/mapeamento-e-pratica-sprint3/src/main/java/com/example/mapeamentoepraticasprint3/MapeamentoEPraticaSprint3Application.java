package com.example.mapeamentoepraticasprint3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MapeamentoEPraticaSprint3Application {

	public static void main(String[] args) {
		SpringApplication.run(MapeamentoEPraticaSprint3Application.class, args);
	}

}
