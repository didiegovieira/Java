package school.sptech.dynamicfinders;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DynamicFindersApplication {

	public static void main(String[] args) {
		SpringApplication.run(DynamicFindersApplication.class, args);
	}

}
