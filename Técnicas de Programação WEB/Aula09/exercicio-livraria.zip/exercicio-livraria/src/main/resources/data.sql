INSERT INTO Livro (
    titulo, autor, dataPublicacao, preco, disponibilidadeEstoque
)
VALUES
    ('Dom Casmurro', 'Machado de Assis', '1900-01-01', 19.99, true),
    ('A Metamorfose', 'Franz Kafka', '1915-10-01', 15.99, true),
    ('1984', 'George Orwell', '1949-06-08', 14.99, true),
    ('O Pequeno Príncipe', 'Antoine de Saint-Exupéry', '1943-04-06', 12.99, true),
    ('Cem Anos de Solidão', 'Gabriel García Márquez', '1967-05-30', 22.99, true),
    ('O Senhor dos Anéis', 'J.R.R. Tolkien', '1954-07-29', 29.99, true),
    ('A Culpa é das Estrelas', 'John Green', '2012-01-10', 17.99, true),
    ('Harry Potter e a Pedra Filosofal', 'J.K. Rowling', '1997-06-26', 19.99, true),
    ('Percy Jackson e o Ladrão de Raios', 'Rick Riordan', '2005-06-28', 14.99, true),
    ('As Crônicas de Gelo e Fogo', 'George R.R. Martin', '1996-08-06', 24.99, true);
