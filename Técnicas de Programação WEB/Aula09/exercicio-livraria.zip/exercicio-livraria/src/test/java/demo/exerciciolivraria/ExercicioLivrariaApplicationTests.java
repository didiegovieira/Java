package demo.exerciciolivraria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioLivrariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
