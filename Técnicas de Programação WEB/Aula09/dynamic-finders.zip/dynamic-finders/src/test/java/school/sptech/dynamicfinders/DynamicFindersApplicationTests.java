package school.sptech.dynamicfinders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicFindersApplicationTests {

	@Test
	void contextLoads() {
	}

}
