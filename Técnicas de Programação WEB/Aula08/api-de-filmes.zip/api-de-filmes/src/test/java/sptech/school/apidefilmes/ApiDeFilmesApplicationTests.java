package sptech.school.apidefilmes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiDeFilmesApplicationTests {

	@Test
	void contextLoads() {
	}

}
