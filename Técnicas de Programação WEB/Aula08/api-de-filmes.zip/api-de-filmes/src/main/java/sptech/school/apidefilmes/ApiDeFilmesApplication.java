package sptech.school.apidefilmes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiDeFilmesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiDeFilmesApplication.class, args);
	}

}
