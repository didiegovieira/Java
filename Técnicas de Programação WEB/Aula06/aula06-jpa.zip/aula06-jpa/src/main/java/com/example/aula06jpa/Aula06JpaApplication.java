package com.example.aula06jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula06JpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula06JpaApplication.class, args);
	}

}
