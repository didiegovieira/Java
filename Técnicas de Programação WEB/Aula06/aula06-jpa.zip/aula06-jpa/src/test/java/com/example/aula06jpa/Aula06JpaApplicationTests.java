package com.example.aula06jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula06JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
