INSERT INTO usuario
            (nome, sobrenome, cpf, email, data_nascimento)
      VALUES
            ('João', 'Silva', '57903074423', 'joao.silva@gmail', '2023-01-01'),
            ('Maria', 'Santos', '34391372363', 'maria.santos@gmail', '2023-01-01'),
            ('José', 'Souza', '22382920203', 'jose.souza@gmail', '2023-01-01'),
            ('Ana', 'Oliveira', '06870865310', 'ana.oliveira@gmail', '2023-01-01'),
            ('Francisco', 'Santos', '68462244919', 'francisco.santos@gmail', '2023-01-01'),
            ('Ana', 'Silva', '54279281386', 'ana.silva@gmail', '2023-01-01'),
            ('Carlos', 'Souza', '91470565099', 'carlos.souza@gmail', '2023-01-01'),
            ('Paulo', 'Oliveira', '76945482316', 'paulo.oliveira@gmail', '2023-01-01'),
            ('Pedro', 'Silva', '16116793703', 'pedro.silva@gmail', '2023-01-01'),
            ('Lucas', 'Santos', '53853768415', 'lucas.santos@gmail', '2023-01-01'),
            ('Marcos', 'Souza', '33673381415', 'marcos.souza@gmail', '2023-01-01'),
            ('Marcos', 'Oliveira', '20358229634', 'marcos.oliveira@gmail', '2023-01-01');
