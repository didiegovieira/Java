package school.sptech.atividade1.controller.dto;

import lombok.Data;

import java.time.LocalDate;

//FIXME: Completar a classe
@Data
public class UsuarioSimpleResponse {
    private Integer id;
    private String nomeCompleto;
}
