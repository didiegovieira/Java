package school.sptech.atividade1.utils;

public class UsuarioCreateRequestDtoUtil {

    public static final String USUARIO_CREATE_REQUEST_DTO_NOME = "nome";
    public static final String USUARIO_CREATE_REQUEST_DTO_SOBRENOME = "sobrenome";
    public static final String USUARIO_CREATE_REQUEST_DTO_CPF = "cpf";
    public static final String USUARIO_CREATE_REQUEST_DTO_EMAIL = "email";
    public static final String USUARIO_CREATE_REQUEST_DTO_DATA_NASCIMENTO = "dataNascimento";
}
