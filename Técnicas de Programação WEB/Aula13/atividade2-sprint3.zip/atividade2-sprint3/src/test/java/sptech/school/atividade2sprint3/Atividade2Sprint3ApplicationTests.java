package sptech.school.atividade2sprint3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade2Sprint3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
