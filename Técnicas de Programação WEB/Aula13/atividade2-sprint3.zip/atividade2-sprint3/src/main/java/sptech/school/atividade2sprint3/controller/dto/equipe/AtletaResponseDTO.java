package sptech.school.atividade2sprint3.controller.dto.equipe;

import lombok.Data;

@Data
public class AtletaResponseDTO {
    private Integer id;
    private String nome;
    private Integer idade;
    private String posicao;
}
