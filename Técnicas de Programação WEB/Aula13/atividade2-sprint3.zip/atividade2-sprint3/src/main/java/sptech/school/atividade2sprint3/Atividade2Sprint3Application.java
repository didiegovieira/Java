package sptech.school.atividade2sprint3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Atividade2Sprint3Application {

	public static void main(String[] args) {
		SpringApplication.run(Atividade2Sprint3Application.class, args);
	}

}
