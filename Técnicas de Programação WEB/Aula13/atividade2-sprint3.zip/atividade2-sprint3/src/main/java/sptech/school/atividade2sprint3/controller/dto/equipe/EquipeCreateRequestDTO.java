package sptech.school.atividade2sprint3.controller.dto.equipe;

import lombok.Data;

@Data
public class EquipeCreateRequestDTO {
    private String nome;
    private String nomeDoTecnico;
}
