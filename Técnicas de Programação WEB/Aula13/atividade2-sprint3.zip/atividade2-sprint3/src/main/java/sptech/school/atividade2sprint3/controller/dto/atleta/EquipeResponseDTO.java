package sptech.school.atividade2sprint3.controller.dto.atleta;

import lombok.Data;

@Data
public class EquipeResponseDTO {
    private Integer id;
    private String nome;
    private String nomeDoTecnico;
}
