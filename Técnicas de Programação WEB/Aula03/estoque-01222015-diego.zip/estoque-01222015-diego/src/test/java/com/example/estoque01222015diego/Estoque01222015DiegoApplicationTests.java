package com.example.estoque01222015diego;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Estoque01222015DiegoApplicationTests {

	@Test
	void contextLoads() {
	}

}
