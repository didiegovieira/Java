package com.example.estoque01222015diego;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Estoque01222015DiegoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Estoque01222015DiegoApplication.class, args);
	}

}
