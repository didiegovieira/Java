package sptech.school.relacionamento1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Relacionamento1Application {

	public static void main(String[] args) {
		SpringApplication.run(Relacionamento1Application.class, args);
	}

}
