package sptech.school.atividadevalidation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtividadeValidationApplicationTests {

	@Test
	void contextLoads() {
	}

}
