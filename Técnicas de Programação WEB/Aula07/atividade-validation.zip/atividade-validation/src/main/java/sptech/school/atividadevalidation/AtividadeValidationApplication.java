package sptech.school.atividadevalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtividadeValidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtividadeValidationApplication.class, args);
	}

}
