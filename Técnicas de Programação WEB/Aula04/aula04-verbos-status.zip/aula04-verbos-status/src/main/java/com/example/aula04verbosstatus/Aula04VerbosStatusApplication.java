package com.example.aula04verbosstatus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula04VerbosStatusApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula04VerbosStatusApplication.class, args);
	}

}
