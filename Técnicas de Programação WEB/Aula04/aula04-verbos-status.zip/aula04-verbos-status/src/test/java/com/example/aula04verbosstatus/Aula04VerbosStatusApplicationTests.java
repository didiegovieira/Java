package com.example.aula04verbosstatus;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula04VerbosStatusApplicationTests {

	@Test
	void contextLoads() {
	}

}
