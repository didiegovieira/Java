package aula05exercicios.aula05exercicios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Aula05ExerciciosApplication {

	public static void main(String[] args) {
		SpringApplication.run(Aula05ExerciciosApplication.class, args);
	}

}
